<?php 

// define("DB_SERVER", "localhost");
// define("DB_USER", "sally");
// define("DB_PASS", "P@ssword1234");
// define("DB_NAME", "salamanders");

define("DB_SERVER", "localhost");
define("DB_USER", "taylorwc_wbip");
define("DB_PASS", "AllAlone1023!!");
define("DB_NAME", "taylorwc_SAS");



