<?php require_once('../../private/initialize.php');

$pageTitle = 'Create Salamander'; ?>

 <?php include('../../private/shared/salamander-header.php'); ?>

 <h1>stub for Create Salamander</h1>
<?php include('../../private/shared/salamander-footer.php'); ?>
