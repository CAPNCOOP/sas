<?php require_once('../../private/initialize.php');

$pageTitle = 'Delete Salamander'; ?>

 <?php include('../../private/shared/salamander-header.php'); ?>

 <h1>stub for Delete Salamander</h1>
<?php include('../../private/shared/salamander-footer.php'); ?>
