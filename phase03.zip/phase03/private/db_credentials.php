<?php 

// define("DB_SERVER", "localhost");
// define("DB_USER", "sally");
// define("DB_PASS", "P@ssword1234");
// define("DB_NAME", "salamanders");

define("DB_SERVER", "taylorwc_SAS");
define("DB_USER", "taylorwc_wbip");
define("DB_PASS", "1022");
define("DB_NAME", "taylorwc_SAS");



